export type TPagination<T> = {
    data: T;
    page_size: number;

  };
  