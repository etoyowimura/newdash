export type TService = {
    id:     number;
    title:  string;
    points: number;
}
