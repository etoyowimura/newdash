export type TCustomer = {
    id:         number;
    name:       string;
    profession: string;
    company_id: number;
    is_active:  boolean;
}
