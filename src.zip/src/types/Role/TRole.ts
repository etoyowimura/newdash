export type TRole = {
    id:   number;
    name: string;
}
