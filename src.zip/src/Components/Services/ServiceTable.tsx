import React from "react";
import { Modal, Spin, Table } from "antd";
import {
  QueryObserverResult,
  RefetchOptions,
  RefetchQueryFilters,
} from "react-query";
import { TService } from "../../types/Service/TService";
import { isMobile, role } from "../../App";

const { confirm } = Modal;

type numStr = string | number;

const ServiceTable = ({
  data,
  isLoading,
  refetch,
}: {
  data: TService[] | undefined;
  isLoading: boolean | undefined;
  refetch: <TPageData>(
    options?: (RefetchOptions & RefetchQueryFilters<TPageData>) | undefined
  ) => Promise<QueryObserverResult<TService[], unknown>>;
}) => {
  return (
    <div>
      <Table
        loading={isLoading}
        onRow={(record) => {
          return {
            onClick: () => {
              role !== "Checker" &&
                document.location.replace(`/#/services/${record.id}`);
            },
          };
        }}
        dataSource={data?.map((u, i) => ({
          no: i + 1,
          title: u?.title,
          points: u?.points,
          id: u?.id,
          action: { id: u.id },
          key: u.id,
        }))}
        columns={[
          {
            title: "No",
            dataIndex: "no",
          },
          {
            title: "Title",
            dataIndex: "title",
          },
          {
            title: "Points",
            dataIndex: "points",
          },
        ]}
        size={isMobile ? "small" : "middle"}
      />
    </div>
  );
};

export default ServiceTable;
